import 'package:flutter/material.dart';
import 'office_detail_page.dart';

class OfficesPage extends StatelessWidget {
  final List<Map<String, String>> offices = [
    {"name": "Istanbul Ofisi", "location": "İstanbul"},
    {"name": "Ankara Ofisi", "location": "Ankara"},
    {"name": "Kocaeli Ofisi", "location": "Kocaeli"},
    {"name": "Izmir Ofisi", "location": "İzmir"},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue.withOpacity(0.7), // Şeffaf AppBar
        elevation: 0,
        title: const Text(
          "Şirketler",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Stack(
        children: [
          // Arka Plan Resmi
          Positioned.fill(
            child: Image.asset(
              "lib/assets/image/blob4.png", // Resim yolu
              fit: BoxFit.cover,
            ),
          ),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.transparent,
                  Colors.transparent,
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
            child: ListView.builder(
              padding: const EdgeInsets.all(16.0),
              itemCount: offices.length,
              itemBuilder: (context, index) {
                final office = offices[index];
                return GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => OfficeDetailPage(
                          name: office["name"]!,
                          location: office["location"]!,
                        ),
                      ),
                    );
                  },
                  child: Card(
                    margin: const EdgeInsets.only(bottom: 16.0),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12.0),
                    ),
                    elevation: 4,
                    color: Colors.blue.shade800,
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            office["name"]!,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            office["location"]!,
                            style: const TextStyle(
                              fontSize: 14,
                              color: Colors.white70,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        selectedItemColor: Colors.blue.shade700,
        unselectedItemColor: Colors.grey,
        currentIndex: 1,
        onTap: (index) {
          // Alt menüde gezinme
          if (index == 0) Navigator.pushNamed(context, '/home');
          if (index == 1) {};
          if (index == 2) Navigator.pushNamed(context, '/faultydevices');
          if (index == 3) Navigator.pushNamed(context, '/profile');
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Anasayfa'),
          BottomNavigationBarItem(icon: Icon(Icons.business), label: 'Ofisler'),
          BottomNavigationBarItem(
              icon: Icon(Icons.devices), label: 'Arızalı Cihazlar'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profil'),
        ],
      ),
    );
  }
}
