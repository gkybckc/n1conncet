import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Arka Plan Resmi
          Positioned.fill(
            child: Image.asset(
              "lib/assets/image/blob1.png", // Resim yolu
              fit: BoxFit.cover,
            ),
          ),
          Container(
            padding: const EdgeInsets.all(16.0),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.blue.shade900,
                  Colors.blue.shade600,
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
            child: Column(
              children: [
                // Profil Görseli
                const CircleAvatar(
                  radius: 50,
                  backgroundImage: AssetImage("assets/profile_picture.png"), // Resim yolu
                  backgroundColor: Colors.white,
                ),
                const SizedBox(height: 16),
                // Kullanıcı Adı
                const Text(
                  "Kullanıcı Adı",
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 8),
                // E-posta Adresi
                const Text(
                  "email@example.com",
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white70,
                  ),
                ),
                const SizedBox(height: 16),
                // Diğer Bilgiler
                Expanded(
                  child: ListView(
                    children: [
                      buildInfoCard("Telefon Numarası", "123-456-7890"),
                      buildInfoCard("Şirket", "N1iletişim"),
                      buildInfoCard("Pozisyon", "Proje Lideri"),
                      buildInfoCard("Katılma Tarihi", "01 Ocak 2023"),
                    ],
                  ),
                ),
                // Çıkış Yap Butonu
                ElevatedButton(
                  onPressed: () {
                    Navigator.pushNamedAndRemoveUntil(context, '/', (route) => false);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: const Text(
                    "Çıkış Yap",
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        selectedItemColor: Colors.blue.shade700,
        unselectedItemColor: Colors.grey,
        currentIndex: 3, // Profil sekmesi aktif
        onTap: (index) {
          // Alt menüde gezinme
          if (index == 0) Navigator.pushNamed(context, '/home');
          if (index == 1) Navigator.pushNamed(context, '/office');
          if (index == 2) Navigator.pushNamed(context, '/faultydevices');
          if (index == 3) {} // Profil zaten açık
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Anasayfa'),
          BottomNavigationBarItem(icon: Icon(Icons.business), label: 'Ofisler'),
          BottomNavigationBarItem(icon: Icon(Icons.devices), label: 'Arızalı Cihazlar'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profil'),
        ],
      ),
    );
  }

  // Profil Detay Kartı
  Widget buildInfoCard(String title, String value) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12.0),
      ),
      color: Colors.blue.shade800,
      child: ListTile(
        title: Text(
          title,
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          value,
          style: const TextStyle(color: Colors.white70),
        ),
      ),
    );
  }
}
