import 'package:flutter/material.dart';
import 'device_detail_page.dart';

class DevicesPage extends StatelessWidget {
  final List<Map<String, String>> devices = [
    {"name": "Laptop", "status": "Çalışıyor"},
    {"name": "Yazıcı", "status": "Arızalı"},
    {"name": "Projeor", "status": "Bakımda"},
    {"name": "Masaüstü Bilgisayar", "status": "Çalışıyor"},
    {"name": "Telefon", "status": "Çalışıyor"},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        elevation: 0,
        title: const Text(
          "Cihazlar",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Stack(
        children: [
          // Arka plan resmi
          Positioned.fill(
            child: Image.asset(
              "lib/assets/image/blob5.png", // Resmin yolu
              fit: BoxFit.cover,
            ),
          ),
          // Üst katman: Cihaz listesi
          ListView.builder(
            padding: const EdgeInsets.all(16.0),
            itemCount: devices.length,
            itemBuilder: (context, index) {
              final device = devices[index];
              return GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => DeviceDetailPage(
                        name: device["name"]!,
                        status: device["status"]!,
                      ),
                    ),
                  );
                },
                child: Card(
                  margin: const EdgeInsets.only(bottom: 16.0),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                  elevation: 4,
                  color: Colors.blue.shade800.withOpacity(0.8), // Arka planı yarı saydam
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          device["name"]!,
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          "Durum: ${device["status"]!}",
                          style: const TextStyle(
                            fontSize: 14,
                            color: Colors.white70,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        selectedItemColor: Colors.blue.shade700,
        unselectedItemColor: Colors.grey,
        currentIndex: 2,
        onTap: (index) {
          // Alt menüde gezinme
          if (index == 0) Navigator.pushNamed(context, '/home');
          if (index == 1) Navigator.pushNamed(context, '/office');
          if (index == 2) Navigator.pushNamed(context, '/faultydevices');
          if (index == 3) Navigator.pushNamed(context, '/profile'); // Profil zaten açık
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Anasayfa'),
          BottomNavigationBarItem(icon: Icon(Icons.business), label: 'Ofisler'),
          BottomNavigationBarItem(icon: Icon(Icons.devices), label: 'Arızalı Cihazlar'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profil'),
        ],
      ),
    );
  }
}
