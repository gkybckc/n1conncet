import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final List<Map<String, String>> offices = [
    {"name": "Istanbul Ofisi", "status": "15 Cihaz Aktif"},
    {"name": "Ankara Ofisi", "status": "2 Cihaz Sorunlu"},
    {"name": "Kocaeli Ofisi", "status": "10 Cihaz Aktif"},
    {"name": "Izmir Ofisi", "status": "1 Cihaz Sorunlu"},
  ];

  List<Map<String, String>> filteredOffices = [];
  String searchQuery = "";

  @override
  void initState() {
    super.initState();
    filteredOffices = offices; // İlk durumda tüm liste gösterilir
  }

  void updateSearch(String query) {
    setState(() {
      searchQuery = query.toLowerCase();
      filteredOffices = offices.where((office) {
        return office["name"]!.toLowerCase().contains(searchQuery);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue.withOpacity(0.7), // Şeffaflık eklendi
        elevation: 0,
        title: const Text(
          "Anasayfa",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: Stack(
        children: [
          // Arka Plan Resmi
          Positioned.fill(
            child: Image.asset(
              "lib/assets/image/blob2.png", // Resim yolu
              fit: BoxFit.cover,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                // Arama Çubuğu
                TextField(
                  onChanged: updateSearch,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Colors.white,
                    hintText: "Ara...",
                    hintStyle: const TextStyle(color: Colors.grey),
                    prefixIcon: const Icon(Icons.search, color: Colors.grey),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                // Ofislerin Durumu Kartları
                Expanded(
                  child: ListView.builder(
                    itemCount: filteredOffices.length,
                    itemBuilder: (context, index) {
                      final office = filteredOffices[index];
                      return buildOfficeCard(
                        context,
                        office["name"]!,
                        office["status"]!,
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        selectedItemColor: Colors.blue.shade700,
        unselectedItemColor: Colors.grey,
        currentIndex: 0, // Anasayfa sekmesi aktif
        onTap: (index) {
          // Alt menüde gezinme
          if (index == 1) Navigator.pushNamed(context, '/office');
          if (index == 2) Navigator.pushNamed(context, '/faultydevices');
          if (index == 3) Navigator.pushNamed(context, '/profile');
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Anasayfa'),
          BottomNavigationBarItem(icon: Icon(Icons.business), label: 'Ofisler'),
          BottomNavigationBarItem(icon: Icon(Icons.devices), label: 'Arızalı Cihazlar'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profil'),
        ],
      ),
    );
  }

  // Ofis Kartı Tasarımı
  Widget buildOfficeCard(BuildContext context, String officeName, String status) {
    // Duruma göre renk belirleme
    final bool isActive = status.contains("Aktif");
    final Color statusColor = isActive ? Colors.green : Colors.red;

    return GestureDetector(
      onTap: () {
        // Ofis Detay Sayfasına Yönlendirme
        Navigator.pushNamed(context, '/devices');
      },
      child: Card(
        margin: const EdgeInsets.only(bottom: 12.0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12.0),
        ),
        color: Colors.blue.shade800,
        child: ListTile(
          title: Text(
            officeName,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          subtitle: Text(
            status,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: statusColor, // Duruma göre kırmızı/yeşil
            ),
          ),
          trailing: const Icon(Icons.arrow_forward, color: Colors.white),
        ),
      ),
    );
  }
}
