import 'package:flutter/material.dart';

import 'faulty_device_detail_page.dart';

class FaultyDevicesPage extends StatelessWidget {
  final List<Map<String, String>> faultyDevices = [
    {
      "name": "Yazıcı",
      "code": "PRT-001",
      "company": "Şirket A",
    },
    {
      "name": "Tarayıcı",
      "code": "SCN-002",
      "company": "Şirket B",
    },
    {
      "name": "Monitör",
      "code": "MNT-003",
      "company": "Şirket C",
    },
  ];

  FaultyDevicesPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Arızalı Cihazlar"),
        backgroundColor: Colors.red,
      ),
      body: Stack(
        children: [
          // Arka plan resmi
          Positioned.fill(
            child: Image.asset(
              "lib/assets/image/blob3.png", // Resmin yolu
              fit: BoxFit.cover,
            ),
          ),
          // Üst katman: Liste
          ListView.builder(
            itemCount: faultyDevices.length,
            itemBuilder: (context, index) {
              final device = faultyDevices[index];

              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: ListTile(
                  title: Text(
                    device["name"]!,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Kod: ${device["code"]!}"),
                      Text("Şirket: ${device["company"]!}"),
                    ],
                  ),
                  onTap: () {
                    // Cihaz detay sayfasına yönlendirme
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => FaultyDeviceDetailPage(
                          name: device["name"]!,
                          code: device["code"]!,
                          company: device["company"]!,
                        ),
                      ),
                    );
                  },
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
