import 'package:flutter/material.dart';

class DrawerMenu extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        children: [
          // Profil alanı
          DrawerHeader(
            decoration: BoxDecoration(color: Colors.blue),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: Colors.white,
                  child: Icon(Icons.person, size: 40, color: Colors.blue),
                ),
                const SizedBox(width: 16),
                Text(
                  "Kullanıcı Adı",
                  style: TextStyle(color: Colors.white, fontSize: 20),
                ),
              ],
            ),
          ),
          Divider(thickness: 1, color: Colors.grey[300]),
          // Menü öğeleri
          ListTile(
            leading: Icon(Icons.home),
            title: Text("Anasayfa"),
            onTap: () {
              Navigator.pop(context); // Menü kapatılır
              Navigator.pushNamed(context, '/home'); // Anasayfa'ya yönlendirme
            },
          ),
          ListTile(
            leading: Icon(Icons.business),
            title: Text("Ofisler"),
            onTap: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/offices');
            },
          ),
          ListTile(
            leading: Icon(Icons.devices),
            title: Text("Cihazlar"),
            onTap: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/devices');
            },
          ),
          ListTile(
            leading: Icon(Icons.person),
            title: Text("Profil"),
            onTap: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/profile');
            },
          ),
        ],
      ),
    );
  }
}
