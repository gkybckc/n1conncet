import 'package:flutter/material.dart';

class DeviceCard extends StatelessWidget {
  final String name;
  final String status;
  final Color backgroundColor;
  final VoidCallback onTap;

  const DeviceCard({
    required this.name,
    required this.status,
    required this.backgroundColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        color: backgroundColor,
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.computer, size: 50, color: Colors.white),
              Text(name, style: TextStyle(color: Colors.white)),
              Text(status, style: TextStyle(color: Colors.white)),
            ],
          ),
        ),
      ),
    );
  }
}
