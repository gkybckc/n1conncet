import 'package:flutter/material.dart';

class OfficeCard extends StatelessWidget {
  final String name;
  final String status;
  final String date;
  final String time;
  final Color backgroundColor;
  final VoidCallback onTap;

  const OfficeCard({
    required this.name,
    required this.status,
    required this.date,
    required this.time,
    required this.backgroundColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: backgroundColor,
      child: ListTile(
        title: Text(name, style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text("$date - $time"),
        trailing: Text(status),
        onTap: onTap,
      ),
    );
  }
}
