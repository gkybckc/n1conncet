import 'package:flutter/material.dart';
import 'pages/devices_page.dart';
import 'pages/faulty_device_page.dart';
import 'pages/home_page.dart';
import 'pages/login_page.dart';
import 'pages/office_detail_page.dart';
import 'pages/offices_page.dart';
import 'pages/profile_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'N1iletisimConnect',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/', // Başlangıç rotası
      routes: {
        '/': (context) => const LoginPage(),
        '/home': (context) => HomePage(),
        '/office': (context) => OfficesPage(),
        '/office_detail': (context) => OfficeDetailPage(
          location: "Bir Lokasyon",
          name: "Bir Ofis",
        ),
        '/profile': (context) => ProfilePage(),
        '/devices': (context) => DevicesPage(),
        '/faultydevices': (context) => FaultyDevicesPage()
      },
    );
  }
}
